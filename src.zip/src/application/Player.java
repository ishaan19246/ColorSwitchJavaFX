package application;


public class Player {
	
}





