package application;

public interface Controller {
    void initializeData(int k, int p);
}
